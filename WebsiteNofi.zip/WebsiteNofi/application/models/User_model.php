<?php
class User_model extends CI_model
{
    public function cariUser() 
    {
        $userName = $this->input->post('username', true);
        $passWord = $this->input->post('password', true);
        $this->db->like('idUser',$userName);
        $this->db->like('password',$passWord);
		return $this->db->get('USER')->result_array();
    }

    public function userLogin($data)
    {
        $this->db->where('userName',$data['userName']);
        $this->db->where('password',$data['password']);
        $query = $this->db->get('USER');

        if($query->num_rows() > 0){
			return TRUE;
		}
		else {
			return FALSE;
		}
    }

    public function updateDataUser($data) 
    {
        $this->db->where('idUser',$data['idUser']);
        $this->db->update('USER',$data);
    }

    public function getUser($data)
    {
        $this->db->where('userName',$data['userName']);
        $this->db->where('password',$data['password']);
        return $this->db->get('USER')->row_array();  
    }
}