<?php
class Studio_model extends CI_model
{
    public function getAllStudio() 
	{
		return $query = $this->db->get('STUDIO')->result_array();
	}

	public function getStudioByNo($noStudio) 
	{
		return $this->db->get_where('STUDIO',['noStudio' => $noStudio])->row_array();
	}

}