<?php
class Film_model extends CI_model
{
    public function getAllFilm()
    {
        $this->db->order_by('tahun', 'desc');
        return $query = $this->db->get('film')->result_array();
    }

    public function getAllFilmShow() 
    {
        $this->db->distinct();
        $this->db->select('*');
        $this->db->from('FILM');
        $this->db->join('JADWAL', 'JADWAL.idFilm = FILM.idFilm');
        $this->db->where('tanggal >=',20210614);                   # $this->db->where('tanggal >=',date("Y-m-d")); to use current date
        $this->db->where('tampilkan','True');
        $this->db->group_by('FILM.idFilm');
        $data = $this->db->get()->result_array();

        return $data;
        #$sql = "SELECT DISTINCT * FROM `FILM` JOIN `JADWAL` ON `JADWAL`.`idFilm` = `FILM`.`idFilm` WHERE `tanggal` >= \'%2021-06-14%\' AND tampilkan=\'True\' GROUP BY FILM.idFilm";
        #return $mysqli ->query($sql)->result_array(); 
        
        #return $query = $this->db->get_where('FILM',['tampilkan' => 'True'])->result_array();
    }

    public function getAllFilmToday()
    {
        $this->db->distinct();
        $this->db->select('*');
        $this->db->from('FILM');
        $this->db->join('JADWAL', 'JADWAL.idFilm = FILM.idFilm');
        $this->db->like('tanggal', 20210614);                     # $this->db->like('tanggal',date("Y-m-d")); to use current date
        $this->db->group_by('FILM.idFilm');
        $data = $this->db->get()->result_array();

        return $data;
        

    }

    public function tambahDataFilm($data)
    {
        $this->db->insert('FILM',$data);
    }

    public function hapusDataFilm($idFilm) 
    {
        $this->db->where('idFilm',$idFilm);
		$this->db->delete('FILM');
    }

    public function editFilm($data)
    {
        $this->db->where('idFilm',$data['idFilm']);
        $this->db->update('FILM',$data);
    } 

    public function getFilmById($idFilm)
    {
        return $this->db->get_where('FILM',['idFilm' => $idFilm])->row_array();
    }

    public function cariDataFilm()
	{
		$keyword = $this->input->post('cari', true);
        $this->db->like('judul',$keyword);
		return $this->db->get('FILM')->result_array();

	}

    public function isClear($idFilm) 
	{
		$data = $this->getFilmById($idFilm);
		$query= $this->db->get_where('JADWAL',['idFilm' => $idFilm]);


		if($query->num_rows() > 0){
			return FALSE;
		}
		else {
			return TRUE;
		}
	}

      

}