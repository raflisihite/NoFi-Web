<?php
class Jadwal_model extends CI_model
{
    public function getAllJadwal()
    {
        $this->db->select('*');
        $this->db->from('JADWAL');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudio');
        $this->db->order_by('tanggal');
        return $query = $this->db->get()->result_array();
    }

    public function getAllJadwalShow()
    {
        ###########
    }

    public function getAllJadwalToday()
    {
        ###########
    }

    public function tambahDataJadwal($data)
    {
        $this->db->insert('jadwal',$data);
    }

    public function hapusDataJadwal($idJadwal)
    {
        $this->db->where('idJadwal',$idJadwal);
		$this->db->delete('JADWAL');
    }

    public function editJadwal($data)
    {
        $this->db->where('idJadwal',$data['idJadwal']);
        $this->db->update('JADWAL',$data);
    }

    public function getJadwalById($idJadwal) 
	{
		return $this->db->get_where('JADWAL',['idJadwal' => $idJadwal])->row_array();

	}

    public function isJadwalClear($data)
	{
		
		$this->db->where('noStudio',$data['noStudio']);
        $this->db->where('tanggal',$data['tanggal']);
        $this->db->where('jamTayang',$data['jamTayang']);
		$query = $this->db->get('JADWAL');


		if($query->num_rows() > 0){
			return FALSE;
		}
		else {
			return TRUE;
		}
	}

    public function isClear($idJadwal) 
	{
		$data = $this->getJadwalById($idJadwal);
		$query= $this->db->get_where('ORDER',['idJadwal' => $data['idJadwal']]);


		if($query->num_rows() > 0){
			return FALSE;
		}
		else {
			return TRUE;
		}
	}

    public function cariDataJadwal()
	{
		$keyword = $this->input->post('cari', true);
       
        
		$this->db->select('*');
        $this->db->from('JADWAL');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudio');
        $this->db->like('judul',$keyword);
        return $this->db->get()->result_array();



		#return $this->db->query('SELECT * FROM `JADWAL` NATURAL JOIN `FILM` WHERE judul= $keyword ')->result_array();

	}

    public function getAllFilm()
    {
        return $query = $this->db->get('FILM')->result_array();
    }

    public function getAllStudio()
    {
        return $query = $this->db->get('STUDIO')->result_array();
    }


    public function getJudulFilm($idFilm)
    {
        $this->db->select('judul');
        $query = $this->db->get('FILM');
        return $query;
    }

    public function getKelasStudio($noStudio)
    {
        $this->db->select('kelas');
        $query = $this->db->get('STUDIO');
        return $query;
    }

    public function getJadwalByFilm($id)
    {
        $this->db->select('*');
        $this->db->from('JADWAL');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudios');
        $this->db->where('JADWAL.idFilm', $id);
        $this->db->where('tanggal >=', date("Y-m-d"));
        $this->db->order_by('tanggal');
        #return $query = $this->db->get()->row_array();
        $today = date("Y-m-d");
        $result = "SELECT * FROM `JADWAL` JOIN `FILM` ON `FILM`.`idFilm` = `JADWAL`.`idFilm` JOIN `STUDIO` ON `STUDIO`.`noStudio` = `JADWAL`.`noStudio` WHERE `JADWAL`.`idFilm` = '$id' AND `tanggal` >= '$today' ORDER BY `tanggal`";

        return $this->db->query($result)->result_array();
    }

    public function getAllJadwalByID($idJadwal)
    {
        $this->db->select('*');
        $this->db->from('JADWAL');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudio');
        $this->db->where('idJadwal >=', $idJadwal);
        return $query = $this->db->get()->row_array();
    }
}