<?php
class Kursi_model extends CI_model
{
    public function getAllKursi() 
	{
		return $query = $this->db->get('KURSI')->result_array();
	}

	public function getKursiByNo($noKursi)  
	{
		return $this->db->get_where('KURSI',['noKursi' => $noKursi])->row_array();
	}

	public function getKursiKosong($idJadwal)
	{
		$this->db->select('*');
        $this->db->from('ORDER');
        $this->db->where('idJadwal', $idJadwal);
        $Kursi = $this->db->get();

		$this->db->select('*');
        $this->db->from('JADWAL');
        $this->db->where('idJadwal', $idJadwal);
		$jadwal = $this->db->get()->row_array();
		$studio = $jadwal['noStudio'];

		if($Kursi->num_rows() > 0){
			$sql = "SELECT * FROM `ORDER` WHERE `idJadwal` = '$idJadwal'";
			$kursi = $this->db->query($sql)->result_array();
			$text =',';
			if($Kursi->num_rows() == 1 ){
				foreach($kursi as $k):
					$text2 = $k['noKursi'];
				endforeach;
			} else {
				$i = 0;
				$len = count($kursi);
				foreach ($kursi as $k) {
    				if ($i == 0) {
        				$text2 = $k['noKursi']."',";
    				} else if ($i == $len - 1) {
        			    $text2 = $text2."'".$k['noKursi'];
    				} else {
						$text2 = $text2."'".$k['noKursi']."',";
					}
    				$i++;
				}
			}
			$usedKursi =$text2;
			$result = "SELECT * FROM `KURSI` WHERE `noStudio` = '$studio' AND `noKursi` NOT IN ('$usedKursi')";
		}
		else {
			$result = "SELECT * FROM `KURSI` WHERE `noStudio` = '$studio'";
		}

		return $this->db->query($result)->result_array();

	}
}