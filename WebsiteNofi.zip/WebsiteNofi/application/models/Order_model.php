<?php
class Order_model extends CI_model
{
    public function getOrderByUser($idUser)
    {
        $this->db->where('idUser', $idUser);
        $this->db->order_by('tglOrder');
        return $this->db->get('ORDER')->result_array();
    }

    public function getOrderById($idOrder)
    {
        return $this->db->get_where('ORDER',['idOrder' => $idOrder])->row_array();
    }

    public function tambahDataOrder($data) 
    {
        $this->db->insert('ORDER',$data);
    }

    public function hapusDataOrder($idOrder)
    {
        $this->db->where('idOrder',$idOrder);
        $this->db->delete('ORDER');
    }

    public function getOrder($id)
    {
        $this->db->select('*');
        $this->db->from('ORDER');
        $this->db->join('JADWAL', 'JADWAL.idJadwal = ORDER.idJadwal');
        $this->db->join('KURSI', 'KURSI.noKursi = ORDER.noKursi');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudio');
        $this->db->where('idUser', $id);
        $this->db->order_by('tglOrder');
        return $query = $this->db->get()->result_array();
    }

    public function getOrderByIdOrder($id)
    {
        $this->db->select('*');
        $this->db->from('ORDER');
        $this->db->join('JADWAL', 'JADWAL.idJadwal = ORDER.idJadwal');
        $this->db->join('KURSI', 'KURSI.noKursi = ORDER.noKursi');
        $this->db->join('FILM', 'FILM.idFilm = JADWAL.idFilm');
        $this->db->join('STUDIO', 'STUDIO.noStudio = JADWAL.noStudio');
        $this->db->where('idOrder', $id);
        $this->db->order_by('tglOrder');
        return $query = $this->db->get()->row_array();
    }


}