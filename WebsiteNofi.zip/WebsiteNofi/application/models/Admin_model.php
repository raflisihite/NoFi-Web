<?php
class Admin_model extends CI_model
{
    public function cariAdmin() #Melakukan pencarian data Admin
    {
        $userName = $this->input->post('username', true);
        $passWord = $this->input->post('password', true);
        $this->db->like('idAdmin',$userName);
        $this->db->like('password',$passWord);
		return $this->db->get('admin')->result_array();
    }

    public function adminLogin($data)
    {
        $this->db->where('adminName',$data['userName']);
        $this->db->where('password',$data['password']);
        $query = $this->db->get('ADMIN');

        if($query->num_rows() > 0){
			return TRUE;
		}
		else {
			return FALSE;
		}
    }
}





