<div class="container">
  <?php if ($this->session->flashdata('flash')) : ?>
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('flash'); ?>.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
  <?php endif; ?>
  
  <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Ubah Data jadwal
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <input type="hidden" name="idJadwal" value="<?= $jadwal['idJadwal'] ?>">
                      <div class="form-group">
                        <label for="judul">Judul Film</label>
                            <select class="form-control" id="idFilm" name="idFilm">
                                <?php foreach ($film as $j) : ?>
                                <?php if ($j['idFilm'] == $jadwal['idFilm']) : ?>
                                <option value="<?= $j['idFilm']; ?>" selected><?= $j['judul']; ?></option>
                                <?php else : ?>
                                <option value="<?= $j['idFilm']; ?>"><?= $j['judul']; ?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                      </div>
                      <div class="form-group">
                        <label for="judul">Kelas Studio</label>
                            <select class="form-control" id="noStudio" name="noStudio">
                                <?php foreach ($studio as $j) : ?>
                                <?php if ($j['noStudio'] == $jadwal['noStudio']) : ?>
                                <option value="<?= $j['noStudio']; ?>" selected><?= $j['kelas']; ?></option>
                                <?php else : ?>
                                <option value="<?= $j['noStudio']; ?>"><?= $j['kelas']; ?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </select>          
                      </div>
                      <div class="form-group">
                          <label for="judul">Jam Tayang</label>
                            <select class="form-control" id="jamTayang" name="jamTayang">
                                <?php foreach ($jam as $j) : ?>
                                <?php if ($j == $jadwal['jamTayang']) : ?>
                                <option value="<?= $j; ?>" selected><?= $j; ?></option>
                                <?php else : ?>
                                <option value="<?= $j; ?>"><?= $j; ?></option>
                                <?php endif; ?>
                                <?php endforeach; ?>
                            </select>      
                      </div>
                      <div class="form-group">
                        <label for="pencegahan">Tanggal Penayangan</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $jadwal['tanggal']; ?>">
                      </div>
                      <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>