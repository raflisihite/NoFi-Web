<div class="container">
    <?php if ($this->session->flashdata('flash')) : ?>
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?= $this->session->flashdata('flash'); ?>.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="row mt-5">
        <div class="col">
            <table class="table mt-5">
                <thead>
                    <tr>
                        <th class="text-center" scope="col">Judul FILM</th>
                        <th class="text-center" scope="col">Kelas Studio</th>
                        <th class="text-center" scope="col">Jam Tayang</th>
                        <th class="text-center" scope="col">Tanggal Pemutaran</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php foreach ($jadwal as $p) : ?>
                        <td class="text-center"><?= $p['judul']; ?></td>
                        <td class="text-center"><?= $p['kelas']; ?></td>
                        <td class="text-center"><?= $p['jamTayang']; ?></td>
                        <td class="text-center"><?= $p['tanggal']; ?></td>
                        <td class="text-center">
                            <a href="<?= base_url(); ?>index.php/adminjadwal/hapus/<?= $p['idJadwal'] ?>" class="badge badge-danger float-center" onclick="return confirm('Apakah anda yakin menghapus data ini?');" ?>Hapus</a>
                            <a href="<?= base_url(); ?>index.php/adminjadwal/ubah/<?= $p['idJadwal'] ?>" class="badge badge-success float-center" ?>ubah</a>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            <div class="row mt-3">
                <div class="col md-6 text-center mt-5">
                    <a href="<?= base_url(); ?>index.php/adminjadwal/tambah " class="btn btn-primary">Tambah</a>
                </div>
            </div>
        </div>
    </div>
</div>