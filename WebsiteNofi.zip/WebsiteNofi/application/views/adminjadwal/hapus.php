<div class="container">
  <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Hapus Data JADWAL
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <div class="form-group">
                        <label for="nama">JADWAL</label>
                        <input type="text" class="form-control" id="nama" name="nama">
                      </div>
                      <button type="submit" name="hapus" class="btn btn-primary float-right">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>