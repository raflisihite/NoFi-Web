<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  <link rel="stylesheet" href="<?= base_url() ?>/styleBeranda.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap" rel="stylesheet">

  <title>Novi - Nonton Film</title>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" onclick="window.location='index.html'"><img src="<?= base_url() ?>/asset/video-roll 1.svg" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>index.php/Beranda/listfilm">List Film</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>index.php/Beranda/sedangtayang">Sedang Tayang</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
        </ul>
        <a href="<?= base_url(); ?>index.php/MainControl" class="nav-link btn-login">Login</a>
      </div>
    </div>
  </nav>
  <!-- Akhir Navbar -->

  <!-- Hero -->
  <section class="content">
    <div class="container text-center text-sm-start">
      <div class="row hero">
        <div class="col-sm-12 col-md-9 col-lg-7 col-xl-5 copywrite offset-sm-0 offset-md-1 offset-xl-0">
          <p class="mini-headline text-uppercase text-white">Baru Minggu Ini!</p>
          <h2 class="text-white">Segera Saksikan Film Kesayangan Anda di Bioskop Terdekat</h2>
          <div class="row mb-2 mt-5">
            <div class="col">
              <div class="container p-xl-0 p-sm-0">
                <button href="<?= base_url(); ?>index.php/Beranda/listfilm" class="btn-lihat">Lihat Film</button>
              </div>
            </div>
          </div>
          <br>
          <img src="<?= base_url() ?>/asset/p1.png" alt="">
          <img src="<?= base_url() ?>/asset/p2.png" alt="">
          <img src="<?= base_url() ?>/asset/p3.png" alt="">
          <img src="<?= base_url() ?>/asset/p4.png" alt="">
          <p class="text-white d-inline-block m-3" style="font-weight: 800;font-size: 24px;">++</p>
          <div class="col">
            <p class="text-white" style="font-weight: 300;font-size: 18px; margin-top: 17px;">Sudah ada ratusan user
              yang bergabung dengan kami. Sekarang giliranmu!</p>
          </div>
        </div>
        <div class="col-lg-4 col-xl-5 d-none d-xl-block mt-3 offset-lg-2">
          <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-indicators">
              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
              <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
            </div>
            <div class="carousel-inner middle">
              <div class="carousel-item active">
                <img src="<?= base_url() ?>/CoverFilm/<?= $film[0]['gbrCover'] ?>" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="<?= base_url() ?>CoverFilm/<?= $film[1]['gbrCover'] ?>" class="d-block w-100" alt="...">
              </div>
              <div class="carousel-item">
                <img src="<?= base_url() ?>CoverFilm/<?= $film[2]['gbrCover'] ?>" class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
              data-bs-slide="prev">
              <span aria-hidden="true"><img src="<?= base_url() ?>asset/back.svg" alt=""></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
              data-bs-slide="next">
              <span aria-hidden="true"><img src="<?= base_url() ?>asset/next.svg" alt=""></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Akhir Hero -->

  <!-- List Film (Sedang Tayang)-->
  <section class="list-film">
    <div class="container mb-3">
      <div class="row">
        <div class="col d-flex justify-content-between">
          <h2>Sedang Tayang</h2>
          <a href="<?= base_url(); ?>index.php/Beranda/sedangtayang" class="nav-link btn-see text-center">Selengkapnya</a>
        </div>
      </div>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <div class="col-sm">
          <div class="card">
            <img src="<?= base_url() ?>CoverFilm/<?= $filmToday[0]['gbrCover'] ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;"><?= $filmToday[0]['judul'] ?></h5>
              <p class="card-text" maxlength="10"><?= $filmToday[0]['sinopsis'] ?></p>
            </div>
          </div>
        </div>
        <div class="col-sm">
          <div class="card">
            <img src="<?= base_url() ?>CoverFilm/<?= $filmToday[1]['gbrCover'] ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;"><?= $filmToday[1]['judul'] ?></h5>
              <p class="card-text"><?= $filmToday[1]['sinopsis'] ?></p>
            </div>
          </div>
        </div>
        <div class="col-sm">
          <div class="card">
            <img src="<?= base_url() ?>CoverFilm/<?= $filmToday[2]['gbrCover'] ?>" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;"><?= $filmToday[2]['judul'] ?></h5>
              <p class="card-text"><?= $filmToday[2]['sinopsis'] ?></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- Akhir List Film (Sedang Tayang) -->

  <!-- List Film (Upcoming) 
  <section class="list-film">
    <div class="container mb-5">
      <div class="row">
        <div class="col d-flex justify-content-between">
          <h2>Upcoming</h2>
          <a href="#" class="nav-link btn-see text-center">Selengkapnya</a>
        </div>
      </div>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <div class="col">
          <div class="card">
            <img src="<?= base_url() ?>/asset/f1.png" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;">Mortal Kombat</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional
                content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src="<?= base_url() ?>/asset/f2.png" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;">Black Widow</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional
                content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card">
            <img src="<?= base_url() ?>/asset/f3.png" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title" style="font-weight: 700;">Land</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional
                content. This content is a little bit longer.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
   Akhir List Film (Upcoming) -->
  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
  </script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
</body>

</html>