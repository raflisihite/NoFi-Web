<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="<?= base_url() ?>/styleBeranda.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap" rel="stylesheet">
    <title>Mortal Kombat</title>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" onclick="window.location='index.html'"><img src="<?= base_url() ?>/asset/video-roll 1.svg" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Sedang Tayang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Upcoming</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Tentang Kami</a>
                    </li>
                </ul>
                <a href="#" class="nav-link btn-daftar">Daftar</a>
                <a href="#" class="nav-link btn-login">Login</a>
            </div>
        </div>
    </nav>
    <!-- Akhir Navbar -->

    <!-- Trailer -->
    <section class="trailer">
        <iframe width="1223" height="707" src="https://www.youtube.com/embed/QJHY4ggYCk4">
        </iframe>
        <div class="container">
            <div class="row mt-5">
                <div class="col-lg-6">
                    <h2>Sinopsis</h2>
                    <p>MMA fighter Cole Young seeks out Earth's greatest champions in order to stand
                        against the enemies
                        of Outworld in a high stakes battle for the universe.</p>
                    <hr>
                    <h2>Review</h2>
                    <div class="review-text">
                        <div>
                            <img src="<?= base_url() ?>/asset/p1.png" alt="">
                            <p class="d-inline-block">"text Review"</p>
                        </div>
                        <div>
                            <img src="<?= base_url() ?>/asset/p1.png" alt="">
                            <p class="d-inline-block">"text Review"</p>
                        </div>
                        <div>
                            <img src="<?= base_url() ?>/asset/p1.png" alt="">
                            <p class="d-inline-block">"text Review"</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 offset-1">
                    <h2>Rating</h2>
                    <p>4/5</p>
                    <p>MMA fighter Cole Young seeks out Earth's greatest champions in order to stand against the enemies
                        of Outworld in a high stakes battle for the universe.</p>
                    <button href="#" class="btn-order mt-3">Order Tiket</button>

                </div>
            </div>
        </div>
    </section>
    <!-- Akhir Trailer -->

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
</body>

</html>