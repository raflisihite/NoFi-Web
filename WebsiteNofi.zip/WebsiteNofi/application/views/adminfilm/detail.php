<div class="container">
  <br><br><br><br>
  <h1><?= $film['judul']; ?></h1><br>
  	<h4>Sinopsis Film</h4>
  		<p><?= $film['sinopsis'] ?></p><br>
  	<h4>Tahun Film</h4>
  		<p><?= $film['tahun'] ?></p><br>
  	<h4>Durasi Film</h4>
  		<p><?= $film['durasi'] ?></p><br>
  	<h4>Gambar Cover</h4>
	  <p><img src="data:image/jpeg;base64,'.base64_encode($film['gbrCover'] ).'" height="200" width="200" class="img-thumnail" /></p><br>
</div>