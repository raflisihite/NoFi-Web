
<div class="container">
	<div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Tambah Data FILM
                </div>
                <div class="card-body">
                <div class="wrapper">
	  <div class="file-upload">
	  	<?php echo $error;?>
	  	<?php echo form_open_multipart('AdminFilm/tambah');?>
      <label for="nama">Upload Gambar Cover Film</label><br/>
	    <input type="file" name="userfile" size="20" />
	    <br/><br />
	    <i class="fa fa-arrow-up"></i>
	  </div>
</div>
                    <form action="" method="post">
  						        <div class="form-group">
    						        <label for="nama">Judul Film</label>
    						        <input type="text" class="form-control" id="judul" name="judul">
  						        </div>
                      <div class="form-group">
                        <label for="gejala">Durasi Film</label>
                        <input type="text" class="form-control" id="durasi" name="durasi">
                      </div>
  						        <div class="form-group">
    						        <label for="gejala">Tahun Rilis Film</label><br>  
    						        <input type="number" id="tahun" name="tahun" min="1900" max="2021">
  						        </div>
                      <div class="form-group">
    						        <label for="gejala">Sinopsis Film</label>
    						        <textarea id="sinopsis" name="sinopsis" rows="4" cols="145"></textarea>
                        <small class="form-text text-danger"><?= form_error('sinopsis') ?></small>
  						        </div>
                      <div class="form-group">
  	                    <label for="gejala">Tampilkan Info Film di Beranda</label><br>
                        <input type="radio" id="True" name="tampilkan" value="True">
                        <label for="True">YA</label>
                        <input type="radio" id="False" name="tampilkan" value="False">
                        <label for="False">TIDAK</label><br>
                      </div>
  						        <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah</button>
                    </form>
				        </div>
            </div>
        </div>
  </div>
</div>