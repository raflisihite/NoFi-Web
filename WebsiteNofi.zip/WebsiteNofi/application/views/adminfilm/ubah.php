<div class="container">
  <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-header text-center">
                    Form Ubah Data Film
                </div>
                <div>
                    <label for="Durasi">Gambar Cover Film</label><br>
                    <img style="padding: left 100px;" width=25% src="<?= base_url() ?>/CoverFilm/<?= $film['gbrCover'] ?>">
                </div>
                <div class="card-body">
                    <form action="" method="post">
                      <input type="hidden" name="idFilm" value="<?= $film['idFilm'] ?>">
                      <div class="form-group">
                        <label for="Judul">Judul Film</label>
                            <input type="text" class="form-control" id="judul" name="judul" value="<?= $film['judul']; ?>">
                            <small class="form-text text-danger"><?= form_error('judul') ?>.</small>
                      </div>
                       <div class="form-group">
                        <label for="Sinopsis">Sinopsis Film</label><br>
                        <! -- <input type="text" class="form-control" id="sinopsis" name="sinopsis" value="<?= $film['sinopsis']; ?>">
                            <textarea id="sinopsis" name="sinopsis" rows="4" cols="145"><?= $film['sinopsis']; ?></textarea>
                            <small class="form-text text-danger"><?= form_error('sinopsis') ?></small>
                      </div>
                      <div class="form-group">
                        <label for="Durasi">Durasi</label>
                        <input type="text" class="form-control" id="durasi" name="durasi" value="<?= $film['durasi']; ?>">
                      </div>
                      <div class="form-group">
                        <label for="Tahun">Tahun Rilis Film</label><br>
                        <input type="number" id="tahun" name="tahun" min="1900" max="2021" value="<?= $film['tahun']; ?>">
                      </div>
                      <div class="form-group">
                        <label for="Tampilkan">Tampilkan Film di Beranda</label><br>
                        <input type="radio" id="True" name="tampilkan" value="True" <?php echo ($film['tampilkan']== 'True') ?  "checked" : "" ;  ?>>
                        <label for="True">YA</label>
                        <input type="radio" id="False" name="tampilkan" value="False" <?php echo ($film['tampilkan']== 'False') ?  "checked" : "" ;  ?>>
                        <label for="False">TIDAK</label><br>
                      </div>
                      <button type="submit" name="ubah" class="btn btn-primary float-right">Ubah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>