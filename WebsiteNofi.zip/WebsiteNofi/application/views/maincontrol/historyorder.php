<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <link rel="stylesheet" href="<?= base_url() ?>/styleHistory.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap" rel="stylesheet">

    <title>Hello, world!</title>
  </head>
  <body>
 <!-- Navbar -->
 <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" onclick=""><img src="<?= base_url() ?>/asset/video-roll 1.svg" alt=""></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>index.php/MainControl/berandaUser">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>index.php/MainControl/listfilmUser">List Film</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url(); ?>index.php/MainControl/sedangtayangUser">Sedang Tayang</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
        </ul>
        <a href="<?= base_url(); ?>index.php/MainControl/userprofil" class="nav-link btn-login"><?= $_SESSION['nama'] ?></a>
        <a href="<?= base_url(); ?>index.php/MainControl/" class="nav-link btn-daftar">logout</a>
      </div>
        </div>
    </nav>
    <!-- Akhir Navbar -->

    <section class="history">
        <div class="container">
            <table class="table" >
                <p class="fs-1"> HISTORY ORDER</p>
                <thead>
                  <tr>
                    <th scope="col">Tanggal Order</th>
                    <th scope="col">Judul Film</th>
                    <th scope="col">Studio</th>
                    <th scope="col">Kursi</th>
                    <th scope="col">Status</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                <?php foreach ($order as $j) : ?>
                  <tr>
                      <th scope="row"><?= $j['tglOrder'] ?></th>
                      <td><?= $j['judul'] ?></td>
                      <td><?= $j['kelas'] ?></td>
                      <td><?= $j['kodeKursi'] ?></td>
                      <td><?= $j['status'] ?></td>
                      <td><a class="btn btn-outline-danger" href="<?= base_url(); ?>index.php/MainControl/historydetail/<?= $j['idOrder'] ?>">Detail</a></td>
                  </tr>            
                <?php endforeach; ?>
                </tbody>
              </table>
        </div>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>